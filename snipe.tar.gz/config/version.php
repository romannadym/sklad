<?php
return array (
  'app_version' => 'v7.0.13',
  'full_app_version' => 'v7.0.13 - build 15514-gdc0949da7',
  'build_version' => '15514',
  'prerelease_version' => '',
  'hash_version' => 'gdc0949da7',
  'full_hash' => 'v7.0.13-265-gdc0949da7',
  'branch' => 'master',
);