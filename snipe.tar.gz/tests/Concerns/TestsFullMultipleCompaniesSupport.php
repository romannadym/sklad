<?php

namespace Tests\Concerns;

interface TestsFullMultipleCompaniesSupport
{
    public function testAdheresToFullMultipleCompaniesSupportScoping();
}
