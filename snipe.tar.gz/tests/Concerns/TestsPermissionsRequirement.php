<?php

namespace Tests\Concerns;

interface TestsPermissionsRequirement
{
    public function testRequiresPermission();
}
